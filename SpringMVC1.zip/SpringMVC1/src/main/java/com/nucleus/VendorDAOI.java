package com.nucleus;

public interface VendorDAOI
{
public int saveVendor(Vendor vendor);
public Vendor searchVendor(int vendorid);
}
