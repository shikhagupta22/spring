package com.nucleus;

public interface VendorSericeI 
{
public int saveVendor(Vendor vendor);
public Vendor searchVendor(int vendorid);
}
